# Exercise 6 Running Instructions

In order to run our exercise, you must first create three (3) Erlang terminals on the same directory as the exercise file ```baltazarcupido.erl```. 



Then, on the first terminal, run the following:

```Initial run
(yves@racoon)1> c(baltazarcupido).
(yves@racoon)2> baltazarcupido:init_chat1().
```

You will be asked to provide a name. Do so.

```Sample run
Enter your name: chat1
```



Then, on the second terminal, run the following:

```Sample run
(george@racoon)2> baltazarcupido:init_chat2().
```

You will also be asked to provide a name.

```Sample run
Enter your name: chat2
```

### 

Then on the third terminal, 

```Sample run
(server@racoon)2> baltazarcupido:init_chat1_server(<Chat1Node>, <Chat2Node>).
```

where: Chat1Node and Chat2Node are the two specific nodes of the two previous terminal. For example, I would be running this:

```Sample run
(server@racoon)2> baltazarcupido:init_chat1_server(yves@racoon, george@racoon).
```

Afterwards, both chat nodes can now chat with each other without waiting for each other's reply, using the server as the "screen". (After each reply, the server will always reply with an acknowledgement token "ACK", but this printing-out can easily be omitted from the code. I simply added it so that you have an overview on how our exercise works.) 



# Other Important Notes for this Exercise

For this exercise, me and my partner had a hard time imagining how it is visually possible in Erlang to show multiple chats from the other user when it is still performing a `receive` operation, since that operation needs to finish first before anything can be executed. As a result, we decided to create an Erlang program that is similar to the client-server architecture.

![table1.png](https://github.com/Yves242/static/blob/main/table1.png?raw=true)

As you can see here, the server connects to the two nodes `chat1` and `chat2`. These nodes will communicate with `Server 1` and the chat will be shown in the `server` node.  The `server` node continually waits for any data from both of these nodes and will log its chats. When one node says "bye", it will tell the other node that it has said bye and should close too. The server closes down thereafter.