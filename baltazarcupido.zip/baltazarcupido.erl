-module(baltazarcupido).
-compile(export_all).

%chat1 initialization
init_chat1() ->
    Name1 = string:strip(io:get_line("Enter your name: "), right, $\n),
    register(chat1, spawn(baltazarcupido, chat1, [Name1])).

%chat1 node
chat1(Name1) ->

    % receive data
    receive

        %if node receives bye, end chat session
        bye ->
            io:format("Your partner has already disconnected. ~n");

        %if node receives message, get message
        {chat1_server, Chat1_server_PID, Server_name, Msg2} ->
            
        %print previous message
            io:format("~s: ~s", [Server_name, Msg2]),

            %get message input
            io:format("~s:", [Name1]),
            Msg1 = io:get_line(" "),
            
            if 
                Msg1 =:= "bye\n" -> Chat1_server_PID ! {chat1, bye, Name1}; %if msg1 is bye, send bye to other node
                Msg1 =/= "bye\n" -> 
                    Chat1_server_PID ! {chat1, Name1, Msg1}, %if msg1 is not bye, send message to other node
                    chat1(Name1)
            end;

        %for initialization of chat
        {chat1_server, Chat1_server_PID} ->
            %get message input
            io:format("~s:", [Name1]),
            Msg1 = io:get_line(" "),

            if 
                Msg1 =:= "bye\n" -> Chat1_server_PID ! {chat1, bye, Name1}; %if msg1 is bye, send bye to other node
                Msg1 =/= "bye\n" -> 
                    Chat1_server_PID ! {chat1, Name1, Msg1}, %if msg1 is not bye, send message to other node
                    chat1(Name1)
            end
    end.

%chat1_server initialization
init_chat1_server(Chat1_node, Chat2_node) ->

    %connect the nodes together
    net_adm:ping(Chat1_node),
    net_adm:ping(Chat2_node),

    % spawn the server
    Server_name = "server",
    spawn(baltazarcupido, chat1_server, [0, Server_name, Chat1_node, Chat2_node]).

%for chat initialization, so that other node knows that there is another connected to it
chat1_server(0, Server_name, Chat1_node, Chat2_node) ->
    
    % send acknowledgement to the two nodes that it's up and running
    {chat1, Chat1_node} ! {chat1_server, self()},
    {chat2, Chat2_node} ! {chat1_server, self()},
    
    % print notification 
    io:format("~nEstablished connection between the two nodes.~n"),

    %proper chat1_server node
    chat1_server(1, Server_name, Chat1_node, Chat2_node, 2).
%chat1_server node for receiving and sending messages
chat1_server(1, Server_name, Chat1_node, Chat2_node, ConnectionCount) ->
    
    receive
        %if node receives bye, end chat session
        {chat1, bye, Name} ->
            {chat2, Chat2_node} ! bye,
            io:format("~s has disconnected.~nSent exit code to other node.~n~nExiting.~n", [Name]);
        
        %if node receives bye, end chat session
        {chat2, bye, Name} ->
            {chat1, Chat1_node} ! bye,
            io:format("~s has disconnected.~nSent exit code to other node.~n~nExiting.~n", [Name]);
        
        %if node receives message, get message
        {chat1, Name1, Msg1} ->
            
            % acknowledge
            {chat1, Chat1_node} ! {chat1_server, self(), Server_name, "ACK\n"}, 
        
            % log to server
            io:format("~s: ~s", [Name1, Msg1]),

            % do again
            chat1_server(1, Server_name, Chat1_node, Chat2_node, ConnectionCount);

        
        %if node receives message, get message
        {chat2, Name3, Msg3} ->
            
            % acknowledge
            {chat2, Chat2_node} ! {chat1_server, self(), Server_name, "ACK\n"}, 
        
            % log to server
            io:format("~s: ~s", [Name3, Msg3]),

            % do again
            chat1_server(1, Server_name, Chat1_node, Chat2_node, ConnectionCount)
    end.

%chat2 initialization
init_chat2() ->
    Name3 = string:strip(io:get_line("Enter your name: "), right, $\n),
    register(chat2, spawn(baltazarcupido, chat2, [Name3])).

%chat2 node
chat2(Name3) ->
    receive
        %if node receives bye, end chat session
        bye ->
            io:format("Your partner has already disconnected. ~n");

        %if node receives message, get message
        {chat1_server, Chat2_server_PID, Server_name, Msg2} ->
            
            %print previous message
            io:format("~s: ~s", [Server_name, Msg2]),

            %get message input
            io:format("~s:", [Name3]),
            Msg3 = io:get_line(" "),
            
            if 
                Msg3 =:= "bye\n" -> Chat2_server_PID ! {chat2, bye, Name3}; %if msg3 is bye, send bye to other node
                Msg3 =/= "bye\n" -> 
                    Chat2_server_PID ! {chat2, Name3, Msg3}, %if msg3 is not bye, send message to other node
                    chat2(Name3)
            end;

        %for initialization of chat
        {chat1_server, Chat2_server_PID} ->
            %get message input
            io:format("~s:", [Name3]),
            Msg3 = io:get_line(" "),

            if 
                Msg3 =:= "bye\n" -> Chat2_server_PID ! {chat2, bye, Name3}; %if msg3 is bye, send bye to other node
                Msg3 =/= "bye\n" -> 
                    Chat2_server_PID ! {chat2, Name3, Msg3}, %if msg3 is not bye, send message to other node
                    chat2(Name3)
            end
    end.
